
<?php

require_once('database.php');  

class profiledisplay extends database
{
	public $datadisplay = array();
	public function profiledisplaydata($id){
		$query = mysqli_query($this->connect(), "SELECT * FROM users WHERE id='$id'");
		$count = mysqli_num_rows($query);
		if ( $count > 0) {
			while ($fetch = mysqli_fetch_assoc($query)) {
				$this->datadisplay[0] = $fetch['username'];
				$data = mysqli_query($this->connect(),"SELECT * FROM experience WHERE ID='$id'");
				$count1 = mysqli_num_rows($data);
				if ($count1>0) {
					while ($fetch1 = mysqli_fetch_assoc($data)) {
						$this->datadisplay[3] = $fetch1['Year_of_exp'];
						$this->datadisplay[4] = $fetch1['Month_name'];
						$this->datadisplay[5] = $fetch1['Job_Location'];
					}
				}
			}
		}
	}


	public function displaydatatat($id){
		$data1 = mysqli_query($this->connect(),"SELECT * FROM job_applied WHERE ID='$id'");
		$count1 = mysqli_num_rows($data1);
		if ($count1>0) {
			while ($fetch2 = mysqli_fetch_assoc($data1)) {
				$this->datadisplay[1] = $fetch2['email'];
				$this->datadisplay[2] = $fetch2['phone'];
			}
		}
				
	}


	public function displayprofiledata($id){
		$data = mysqli_query($this->connect(),"SELECT * FROM experience WHERE ID='$id'");
		$count1 = mysqli_num_rows($data);
		if ($count1>0) {
			while ($fetch1 = mysqli_fetch_assoc($data)) {
				?>
				<li>
					<div class="w-100 float-left">
                    <span class="subtitle w-100"><?php echo $fetch1['Company_name']; ?></span>
                    <span class="second_subtitle w-100 float-left"><?php echo $fetch1['Position_Name']; ?></span>
                    <span class="second_subtitle w-100"><?php echo $fetch1['Job_Location']; ?></span>
                </div>
            </li>
            <?php
        	}
		}
	}


	public function displayprofiledata1($id){
		$data = mysqli_query($this->connect(),"SELECT * FROM education WHERE ID='$id'");
		$count1 = mysqli_num_rows($data);
		if ($count1>0) {
			while ($fetch1 = mysqli_fetch_assoc($data)) {
				?>
				<li>
					<div class="w-100 float-left">
						<span class="subtitle w-100"><?php echo $fetch1['Institute_name']; ?></span>
						<span class="second_subtitle w-100 float-left"><?php echo $fetch1['Qualification']; ?></span>
						<span class="second_subtitle w-100"><?php echo $fetch1['Passing_of_Year']; ?></span>
						<span class="second_subtitle w-100"><?php echo $fetch1['Job_location']; ?></span>
					</div>
				</li>
				
            <?php
        	}
		}
	}


	public function displayprofiledata2($id){
		$data = mysqli_query($this->connect(),"SELECT * FROM others_information WHERE ID='$id'");
		$count1 = mysqli_num_rows($data);
		if ($count1>0) {
			while ($fetch1 = mysqli_fetch_assoc($data)) {
				?>
				<tr>
                        <td class="lable_text">Current Location </td>
                        <td class="infp_text"><?php echo $fetch1['Current_location']; ?></td>
                    </tr>
                    <tr>
                        <td class="lable_text">Preferred Location</td>
                        <td class="infp_text"><?php echo $fetch1['Preferred_location']; ?></td>
                    </tr>
                    <tr>
                        <td class="lable_text">Last Salary </td>
                        <td class="infp_text"><?php echo $fetch1['Last_salary']; ?>.<?php echo $fetch1['last_salary_thousand']; ?> Lakhs per year</td>
                    </tr>
                    <tr>
                        <td class="lable_text">Expecting Salary </td>
                        <td class="infp_text"><?php echo $fetch1['Expecting_salary']; ?>.<?php echo $fetch1['expeted_salary_thousand']; ?> Lakhs per year</td>
                    </tr>
                    <tr>
                        <td class="lable_text">Address </td>
                        <td class="infp_text"><?php echo $fetch1['Address']; ?></td>
                    </tr>
				
            <?php
        	}
		}
	}
}
?>