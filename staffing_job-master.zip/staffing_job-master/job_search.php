<?php
    // Initialize the session
    session_start();
 
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
?>
<?php
    include ("header.php");
    require_once('database.php'); 
    $query="select * from job_list";
    $result=mysqli_query($link, $query);
?>

<?php

    $link = mysqli_query($link,"SELECT COUNT(*) as total_rows FROM job_list" );
   
    $rows=mysqli_fetch_assoc($link);
    $total_rows= $rows['total_rows'];
    //$total_rowss= $rows['total_rowss'];  
?>


<div class="container main_wrapper">
<div class="col-md-4 float-left col-12">
<div class="sidebar mt_20 desktop_view float-left">
    <span style="position: absolute; right: 20px; top: 10px; font-size: 14px;"> <a href="">Edit</a> </span>
    <img src="assets/images/profile.png" class="round_img col-md-2 float-left no-padding">
    <div class="float-left col-md-6 no-padding">
        <span class="primery_title float-left pt_5">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
    <span class="second_subtitle float-left"><?php echo htmlspecialchars($_SESSION["username"]); ?></span>
    </div>
    
</div>
<div class="sidebar mt_20 desktop_view float-left">

    <span class="section_divider"></span>
    <div class="form-group">
        <!-- <label for="exampleInputEmail1">Email address</label> -->
        <input type="email" class="form-control" id="" placeholder="Search by Job title">
    </div> 
    <div class="form-group w-100 float-left">
        <label for="exampleInputEmail1">By Location</label>
        <select class="form-control" id="exampleFormControlSelect1">
            <option>Bangalore</option>
            <option>Mysore</option>
            <option>Kerela</option>
            <option>Mumbai</option>
            <option>Chennai</option>
        </select>
    </div> 
    
    <h1 class="primery_title">Filter by Job Category</h1>
    <div class="form-check w-100 float-left">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Kitchen Job</label>
    </div>
    <div class="form-check w-100 float-left">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">General Jobs</label>
    </div>
    <div class="form-check w-100 float-left">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
         <label class="form-check-label" for="exampleCheck1">General Jobs</label>
    </div>

</div>
</div> <!-- ===  OL_MD 4 right side section end here ========== -->
    <div class="col-md-8 float-left col-12 no-padding">
        <div class="wrapper">
            <h1 class="primery_title pt_30"><?php echo   $total_rows; ?> Jobs Found</h1>    
            
        <ul class="jobs">
        <?php 
          while($row=mysqli_fetch_assoc($result))
                {
            ?>  
            <li>
                <a href="job_details.php?id=<?php echo $row['id']; ?>">
                    <div class="job_container">
                        <div class="job_img">
                        <img src="admin/upload/<?php echo $row['image']; ?>">
                        </div>
                        <div class="job_caption">
                            <span class="primery_title"> <?php echo $row['job_name']; ?> </span>
                            <span class="second_subtitle"> <?php echo $row['company_name']; ?> </span>
                            <!-- <div class="w-100 float-left">
                                <span class="service_price"> ₹ <?php echo $row['vacancy']; ?>  </span>
                                <span class="service_offer ml_10">50% Off</span>
                            </div> -->
                            <ul class="service_tag">
                                <li> <?php echo $row['location']; ?>  </li>
                                <li><?php echo $row['created_at']; ?> </li>
                            </ul>
                        </div>
                    </div>
                </a>
            </li>
          
            <?php     
          }
      ?>    
    </ul> 

        </div>
    </div><!-- ====  COL_MD 8 right side section end here ========== -->
    
    
</div>
<?php include ("footer.php");?>


    