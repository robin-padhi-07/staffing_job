<?php

require_once('database.php');

class editprofile extends database
{
	public $error = array();
	public function editprofiledata()
	{
		if (isset($_POST['firstbutton']) && !empty($_POST['fullname'])) {

			$id = $_POST['id'];
			$fullname = $_POST['fullname'];
			$email = $_POST['email'];
			$number = $_POST['number'];
			$location = $_POST['location'];
			
				mysqli_query($this->connect(), "INSERT INTO job_applied (ID, fullname, email, phone, location) VALUES ('$id', '$fullname', '$email', '$number', '$location')");
			
		}else{
			$this->error[0] = "Please fill all fields";
		}
	}


	public $data = array();
	public function displaydata($id){

		$query = mysqli_query($this->connect(), "SELECT * FROM job_applied WHERE ID = '$id'");
		$count = mysqli_num_rows($query);
		$fetch = mysqli_fetch_assoc($query);
		if ($count>0) {
			$this->data[0] = $fetch['Job_ID'];
			$this->data[1] = $fetch['fullname'];
			$this->data[2] = $fetch['email'];
			$this->data[3] = $fetch['phone'];
			$this->data[4] = $fetch['location'];
		}

	}

	/*for experince from*/

	public function insertdataforexperince(){
		if (isset($_POST['Company_name'])) {

			$id = $_POST['id'];
			$job_ID = $_POST['job_ID'];
			$Company_name = $_POST['Company_name'];
			$position_name = $_POST['position_name'];
			$yearsofexperience = $_POST['yearsofexperience'];
			$month_name = $_POST['month_name'];
			$job_location = $_POST['job_location'];
			
			if (isset($job_ID) && !empty($job_ID)) {
				mysqli_query($this->connect(), "INSERT INTO experience (ID, job_ID, Company_name, Position_Name, Year_of_exp, Month_name, Job_Location) VALUES ('$id', '$job_ID', '$Company_name', '$position_name', '$yearsofexperience', '$month_name', '$job_location')");
				
			}
		}
	}


	public function displaydataexperince(){
		if (isset($_POST['id']) && $_POST['job_ID']) {
			$id = $_POST['id'];
			$job_ID = $_POST['job_ID'];
		
		

			$data = mysqli_query($this->connect(), "SELECT * FROM experience WHERE ID ='$id'");
			$countdata = mysqli_num_rows($data);
			if ($countdata>0) {
				$count = 100;
				while ($fetchdata = mysqli_fetch_assoc($data)) {
					?>
					<li>
						<div class="w-100 float-left">
							<span class="subtitle w-100"><?php echo $fetchdata['Position_Name']; ?>  <a href="profile_edit.php?id=<?php echo $fetchdata['experience_id']; ?>&&userid=<?php echo $fetchdata['ID']; ?>&&eid=<?php echo $fetchdata['job_ID']; ?>">Edit</a>

								<a href="#" id="deleterecord" data-toggle="modal" data-target="#dataview<?php  echo $count; ?>">Remove</a>    </span>
							<span class="second_subtitle w-100 float-left"><?php echo $fetchdata['Company_name']; ?></span>
							<span class="second_subtitle w-100"><?php echo $fetchdata['Year_of_exp']; if ($fetchdata['Year_of_exp']==1) {
								echo "Year";
							}else{
								echo "Years";
							} ?> - <?php echo $fetchdata['Month_name']; if ($fetchdata['Month_name']==1) {
	                           	echo "Month";
	                        }else{
	                           	echo "Months";
	                        } ?></span>
	                          <span class="second_subtitle w-100 float-left"><?php echo $fetchdata['Job_Location']; ?></span>
	                       </div>
	                    </li>
	                    <div id="dataview<?php  echo $count; ?>" class="modal fade" role="dialog">
		                  <div class="modal-dialog">

		                    <!-- Modal content-->
		                    <div class="modal-content">
		                      <div class="modal-body">
		    					Are you sure do you want to delete?                    
		                      </div>
		                      <div class="modal-footer">
		                      	<a href="delete.php?did=<?php echo $fetchdata['experience_id']; ?>&&duserid=<?php echo $fetchdata['ID']; ?>&&deid=<?php echo $fetchdata['job_ID']; ?>" class="btn btn-default">Yes</a>
		                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
		                      </div>
		                    </div>

		                  </div>
		                </div>
					<?php
					$count++;
				}
						
			}else{
				?>
				

				<?php
			}
		}
	}

	public $fetchdata = array();
	public function editfunction($id, $userid, $eid){
		$query = mysqli_query($this->connect(), "SELECT * FROM experience WHERE experience_id='$id' && ID='$userid' && job_ID='$eid'");
		$count = mysqli_num_rows($query);
		if ($count>0) {
			$fetch = mysqli_fetch_assoc($query);

			$this->fetchdata[0] = $fetch['Company_name'];
			$this->fetchdata[1] = $fetch['Position_Name'];
			$this->fetchdata[2] = $fetch['Year_of_exp'];
			$this->fetchdata[3] = $fetch['Month_name'];
			$this->fetchdata[4] = $fetch['Job_Location'];

		}

	}
	
}

$editprofile = new editprofile();
$editprofile->editprofiledata();
$editprofile->insertdataforexperince();
$editprofile->displaydataexperince();
?>