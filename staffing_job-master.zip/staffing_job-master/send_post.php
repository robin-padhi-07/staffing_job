<?php
    // Initialize the session
    session_start();
 
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
?>
<?php 
 
    require_once('admin/common/config.php');
    $user=$_SESSION["username"];
    //echo $user;
    
    $sql = "SELECT * from users where username ='$user'";
    $results = mysqli_query($link, $sql);
    $rows = mysqli_fetch_array($results);
    $id = $rows["id"];
    //print_r($result);
    //echo $row["id"];

    if (isset($_POST['submit'])){

        $title = $_POST['title'];
        $content = $_POST['content'];
        $strsql = "INSERT INTO post(title,content,user_id) VALUES('$title','$content','$id')";
        //print_r($strsql);
        $result=mysqli_query($link, $strsql);
        
    }
?>
