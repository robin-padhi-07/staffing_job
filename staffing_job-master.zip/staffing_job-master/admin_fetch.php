<?php 
    require_once('database.php');  
    $sql = "SELECT users.*, job_applied.*,experience.*, education.*,others_information.* FROM users LEFT JOIN job_applied ON job_applied.ID = users.id LEFT JOIN experience ON experience.ID = job_applied.ID LEFT JOIN education ON education.ID = experience.ID LEFT JOIN others_information ON others_information.ID = education.ID GROUP BY username";
    $qry = mysqli_query($link,$sql);

?>
<script>
   
   /*$(document).ready(function() {
       $('#sample_data').DataTable( {
           "order": [[ 0, "ASC" ]]
       } );
   } );*/
</script>

<div class="col-md-12 float-left mt_10 p_20 bg_white">    
    <table id="sample_data" class="table table-bordered" style="width:100%">
        <thead>
            <tr>
                    <th>ID</th>
                      <th>Employee</th>
                      <th>Job name</th>
                      <th>Company</th>
                      <th>Job Location</th>
                      <th>Job Exp</th>
                      <th>Job Salary</th>
            </tr>
        </thead>
            <tbody>
                <?php 
                if (mysqli_num_rows($qry) > 0) {
                  $count = 1;
                    while($row = mysqli_fetch_assoc($qry)) {
                      $id = $row['id'];
                      $job_ID = $row['job_ID'];
                ?>
                <tr>
                    <td><?php echo $count;?></td>
                    <td> <a href="#" data-toggle="modal" data-target="#dataview<?php  echo $count; ?>"><?php echo $row['username'];?></a> </td>
                    <td><?php echo  $row['Position_Name']; ?></td>
                    <td><?php echo  $row['Company_name']; ?></td>
                    <td><?php echo  $row['Job_Location']; ?></td>
                    <td><?php echo  $row['Year_of_exp'].".".$row['Month_name'];?></td>
                    <td><?php echo  $row['Last_salary'].".".$row['last_salary_thousand'];?></td>

                </tr>

                <div id="dataview<?php  echo $count; ?>" class="modal fade" role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-body">
                        <?php if (isset($row['username'])) {
                          ?>
                          <div>User Name:- <?php echo $row['username']; ?></div>
                          <?php
                        }
                        if (isset($row['fullname'])) {
                          ?>
                          <div>Full Name:- <?php echo $row['fullname']; ?></div>
                          <?php
                        }if (isset($row['email'])) {
                          ?>
                          <div>Email ID:- <?php echo $row['email']; ?></div>
                          <?php
                        }
                        ?>
                        
                        
                        
                        <div>Phone NO:- <?php echo $row['phone']; ?></div>
                        <div>Location:- <?php echo $row['location']; ?></div>
                        <h3>Experience</h3>
                        <?php 
                        $sql1 = "SELECT * FROM experience WHERE ID='$id' && job_ID = '$job_ID'";
                        $data = mysqli_query($link,$sql1);
                        while ($get = mysqli_fetch_assoc($data)) {
                          ?>
                          <div>Company name:- <?php echo $get['Company_name']; ?></div>
                          <div>Position Name:- <?php echo $get['Position_Name']; ?></div>
                          <div>Year of exp:- <?php echo $get['Year_of_exp']." Years ". $row['Month_name']."Months"; ?></div>
                          <div>Job Location:- <?php echo $get['Job_Location']; ?></div></br>
                          <?php
                        }
                         ?>  
                        
                        
                        
                        <h3>Education</h3>
                        <?php
                        $sql2 = "SELECT * FROM education WHERE ID='$id' && job_ID = '$job_ID'";
                        $data1 = mysqli_query($link,$sql2);
                        while ($get1 = mysqli_fetch_assoc($data1)) {
                          ?>
                        <div>Institute name:- <?php echo $get1['Institute_name']; ?></div>
                        <div>Qualification:- <?php echo $get1['Qualification']; ?></div>
                        <div>Passing of Year:- <?php echo $get1['Passing_of_Year']; ?></div>
                        <div>Job Location:- <?php echo $get1['Job_location']; ?></div></br>
                        <?php
                      }
                      ?>
                        <h3>Other Infromation</h3>
                        <div>Current location:- <?php echo $row['Current_location']; ?></div>
                        <div>Preferred location:- <?php echo $row['Preferred_location']; ?></div>
                        <div>Last salary:- <?php echo $row['Last_salary'].".".$row['last_salary_thousand']."Per years"; ?></div>
                        <div>Expecting salary:- <?php echo $row['Expecting_salary'].".".$row['expeted_salary_thousand']."Per Years"; ?></div>
                        <div>Address:- <?php echo $row['Address']; ?></div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>

                  </div>
                </div>
                <?php
                $count++;
                    }
                }else{
                ?>
                    <tr>
                    <td colspan="5">Data not found</td>
                    <?php
                }
                ?>
            </tbody>    
    </table>

</div>