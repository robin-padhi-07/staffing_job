<?php
require_once('database.php');

class updatedataimg extends database
{
	public $err;
	public function uploadfile(){
		$id = $_POST['id'];
		$job_ID = $_POST['job_ID'];
			$filename = $_FILES['file']['name'];
			$file_tmp = $_FILES['file']['tmp_name'];
			$filetype = $_FILES['file']['type'];
			$filesize = $_FILES['file']['size'];
			$location = 'upload/';
			if(!empty($file_tmp)){
				$name = addslashes($filename);
				$new_filename = time()."-".rand(1000, 9999)."-".$name;
				$file_ext = strtolower(end(explode('.', $new_filename)));
				$extensions= array("jpeg","jpg", "png");
				if(in_array($file_ext,$extensions)===false){
					$this->err = "Only jpeg jpg doc docx pdf txt formats allowed";
					$new_filename = "";
					if($filesize > 5000000){
						$this->err = "Please upload Maximum 5MB file";
					}
				}
			}
			$file_name = $location.$new_filename;

			if (empty($this->err)) {
				move_uploaded_file($file_tmp, $file_name);
				mysqli_query($this->connect(), "UPDATE others_information SET adhar='$new_filename' WHERE ID='$id' && job_ID='$job_ID'");
				?>
				<script type="text/javascript">
					window.location.href = "profile_edit.php";
				</script>
				<?php
			}
	}


	public $err1;
	public function uploadfile1(){
		$id = $_POST['id'];
		$job_ID = $_POST['job_ID'];
			$filename = $_FILES['files']['name'];
			$file_tmp = $_FILES['files']['tmp_name'];
			$filetype = $_FILES['files']['type'];
			$filesize = $_FILES['files']['size'];
			$location = 'upload/';
			if(!empty($file_tmp)){
				$name = addslashes($filename);
				$new_filename = time()."-".rand(1000, 9999)."-".$name;
				$file_ext = strtolower(end(explode('.', $new_filename)));
				$extensions= array("jpeg","jpg", "png");
				if(in_array($file_ext,$extensions)===false){
					$this->err1 = "Only jpeg jpg doc docx pdf txt formats allowed";
					$new_filename = "";
					if($filesize > 5000000){
						$this->err1 = "Please upload Maximum 5MB file";
					}
				}
			}
			$file_name = $location.$new_filename;

			if (empty($this->err1)) {
				move_uploaded_file($file_tmp, $file_name);
				mysqli_query($this->connect(), "UPDATE others_information SET pan='$new_filename' WHERE ID='$id' && job_ID='$job_ID'");
				?>
				<script type="text/javascript">
					window.location.href = "profile_edit.php";
				</script>
				<?php
			}
	}



	public function uploadfile2(){
		$id = $_POST['id'];
		$job_ID = $_POST['job_ID'];
			$filename = $_FILES['filess']['name'];
			$file_tmp = $_FILES['filess']['tmp_name'];
			$filetype = $_FILES['filess']['type'];
			$filesize = $_FILES['filess']['size'];
			$location = 'upload/';
			if(!empty($file_tmp)){
				$name = addslashes($filename);
				$new_filename = time()."-".rand(1000, 9999)."-".$name;
				$file_ext = strtolower(end(explode('.', $new_filename)));
				$extensions= array("jpeg","jpg", "png");
				if(in_array($file_ext,$extensions)===false){
					$this->err1 = "Only jpeg jpg doc docx pdf txt formats allowed";
					$new_filename = "";
					if($filesize > 5000000){
						$this->err1 = "Please upload Maximum 5MB file";
					}
				}
			}
			$file_name = $location.$new_filename;

			$querydata = mysqli_query($this->connect(), "SELECT * FROM job_applied WHERE ID='$id'");
			$countt = mysqli_num_rows($querydata);
			if ($countt>0) {
				move_uploaded_file($file_tmp, $file_name);
				mysqli_query($this->connect(), "UPDATE job_applied SET proimg='$new_filename' WHERE ID='$id'");
				header("location:profile_edit.php");
			}else{
				move_uploaded_file($file_tmp, $file_name);
				mysqli_query($this->connect(), "INSERT INTO job_applied (ID, proimg) VALUES ('$id', '$new_filename')");
				header("location:profile_edit.php");
			}
	}



	public $dataimg = array();
	public function viewimg($id){
		
		$data = mysqli_query($this->connect(), "SELECT * FROM others_information WHERE ID='$id'");
		$count = mysqli_num_rows($data);
		if ($count>0) {
			while ($fetch = mysqli_fetch_assoc($data)) {
				$this->dataimg[0] = $fetch['adhar'];
				$this->dataimg[1] = $fetch['pan'];
			}
			
		}

	}

	public $dataimg1 = array();
	public function viewimgpro($id){
		
		$data = mysqli_query($this->connect(), "SELECT * FROM job_applied WHERE ID='$id'");
		$count = mysqli_num_rows($data);
		if ($count>0) {
			while ($fetch = mysqli_fetch_assoc($data)) {
				$this->dataimg1[0] = $fetch['proimg'];
			}
			
		}

	}
}

?>