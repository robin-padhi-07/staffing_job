<?php

require_once('database.php');

class updatedata extends database
{
	
	public function editdata(){
		if (isset($_POST['Company_name'])) {

			$id = $_POST['id'];
			$job_ID = $_POST['job_ID'];
			$Experience_id = $_POST['Experience_id'];
			
			$Company_name = $_POST['Company_name'];
			$position_name = $_POST['position_name'];
			$yearsofexperience = $_POST['yearsofexperience'];
			$month_name = $_POST['month_name'];
			$job_location = $_POST['job_location'];
			mysqli_query($this->connect(),"UPDATE experience SET Company_name='$Company_name', Position_Name='$position_name', Year_of_exp='$yearsofexperience', Month_name='$month_name', Job_Location='$job_location' WHERE experience_id='$Experience_id'");
			
			
		}
	}



	public function educationeditdata(){
		if (isset($_POST['Institutename'])) {

			$id = $_POST['id'];
			$job_ID = $_POST['job_ID'];
			$education_id = $_POST['education_id'];
			
			$Institutename = $_POST['Institutename'];
			$Qualification = $_POST['Qualification'];
			$Passingyears = $_POST['Passingyears'];
			$joblocation = $_POST['joblocation'];
		if (isset($job_ID)) {
			mysqli_query($this->connect(), "UPDATE education SET Institute_name='$Institutename', Qualification='$Qualification', Passing_of_Year='$Passingyears', Job_location='$joblocation' WHERE Education_id='$education_id'");
		}
			
			
			
		}
	}


	public function editprofiledata1()
	{
		if (isset($_POST['fullname']) && !empty($_POST['fullname'])) {

			$id = $_POST['id'];
			$fullname = $_POST['fullname'];
			$email = $_POST['email'];
			$number = $_POST['number'];
			$location = $_POST['location'];
			$data = mysqli_query($this->connect(), "SELECT * FROM job_applied WHERE ID = '$id'");
			$count = mysqli_num_fields($data);
			if ($count>0) {
				mysqli_query($this->connect(), "UPDATE job_applied SET fullname='$fullname', email='$email', phone='$number', location='$location' WHERE ID = '$id'");
			}
		}else{
			$this->error[0] = "Please fill all fields";
		}
	}
	
}

$updatedata = new updatedata();
$updatedata->editdata();
$updatedata->educationeditdata();
$updatedata->editprofiledata1();

?>