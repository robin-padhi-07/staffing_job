# Technical Assessment PHP

Duration: 4-5 hours </br>
Output: Functional php website  </br>
User Type: Employee and Admin </br>
Download the source code from: https://github.com/robin-padhi-07/staffing_job.git

# About the Company

With more than 5 yrs of hands-on experience and dozens of satisfied customers. </br>
Parashar Creative Studio is here to Digitise your Business plan. Our mission to stand out doesn’t stop with our internal goals.</br>
</br>
Website: https://www.wethink.in.net

