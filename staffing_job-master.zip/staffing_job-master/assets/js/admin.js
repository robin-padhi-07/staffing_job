$(document).ready(function() {
    _bindServiceLead();
    //_bindDisplay();
    _bindUpcomingEvent();
});


function _bindServiceLead() {
    $.post("service_lead.php", function(result) {
        $("#content_data").html(result);
    });
}

function _bindUpcomingEvent() {

    $('#myform').submit(function() {
        return false;
    });

    $('#insert').click(function() {
        $.post(
            $('#myform').attr('action'),
            $('#myform :input').serializeArray(),

            function(result) {
                event.preventDefault();
                $('#result').html(result);

            }
        );
    });
}
$(document).ready(function() {

    $('#add_button').click(function() {
        $('#user_form')[0].reset();
        $('.modal-title').text("Add User");
        $('#action').val("Add");
        $('#operation').val("Add");
        $('#user_uploaded_image').html('');
    });
    $(document).ready(function() {
        $('#user_data').DataTable();
    });
    var dataTable = $('#user_data').DataTable({
        "processing": true,
        "serverSide": true,
        "order": [],
        "ajax": {
            url: "fetch.php",
            type: "POST"
        },
        "columnDefs": [{
            "targets": [0, 3, 4],
            "orderable": false,
        }, ],

    });

    // INSERT User Data
    $(document).on('submit', '#user_form', function(event) {
        event.preventDefault();
        var eventName = $('#event_name').val();
        var eventDes = $('#event_des').val();
        var eventLos = $('#location').val();
        var eventLos = $('#s_date').val();
        var extension = $('#user_image').val().split('.').pop().toLowerCase();

        if (extension != '') {
            if (jQuery.inArray(extension, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                alert("Invalid Image File");
                $('#user_image').val('');
                return false;
            }
        }
        if (eventName != '' && eventDes != '' && eventLos != '') {
            $.ajax({
                url: "insert.php",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                success: function(data) {
                    alert(data);
                    $('#user_form')[0].reset();
                    $('#userModal').modal('hide');
                    dataTable.ajax.reload();
                }
            });
        } else {
            alert("Both Fields are Required");
        }
    });

    // Update User Data =============
    $(document).on('click', '.update', function() {
        var user_id = $(this).attr("id");
        $.ajax({
            url: "fetch_single.php",
            method: "POST",
            data: { user_id: user_id },
            dataType: "json",
            success: function(data) {
                $('#userModal').modal('show');
                $('#event_name').val(data.event_name);
                $('#event_des').val(data.event_des);
                $('#location').val(data.location);
                $('#s_date').val(data.s_date);
                $('.modal-title').text("Edit User");
                $('#user_id').val(user_id);
                $('#user_uploaded_image').html(data.user_image);
                $('#action').val("Edit");
                $('#operation').val("Edit");
            }
        })
    });

    $(document).on('click', '.delete', function() {
        var user_id = $(this).attr("id");
        if (confirm("Are you sure you want to delete this?")) {
            $.ajax({
                url: "delete.php",
                method: "POST",
                data: { user_id: user_id },
                success: function(data) {
                    //alert(data);
                    dataTable.ajax.reload();
                }
            });
        } else {
            return false;
        }
    });


});