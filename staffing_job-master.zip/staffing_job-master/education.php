<?php


require_once('database.php');  

class educationdata extends database
{
	
	public function insertdataforeducation(){
		if (isset($_POST['Institutename'])) {

			$id = $_POST['id'];
			$job_ID = $_POST['job_ID'];
			$education_id = $_POST['education_id'];
			
			$Institutename = $_POST['Institutename'];
			$Qualification = $_POST['Qualification'];
			$Passingyears = $_POST['Passingyears'];
			$joblocation = $_POST['joblocation'];
			if (isset($job_ID)) {
				mysqli_query($this->connect(), "INSERT INTO education (ID, job_ID, Institute_name, Qualification, Passing_of_Year, Job_location) VALUES ('$id', '$job_ID', '$Institutename', '$Qualification', '$Passingyears', '$joblocation')");
				
			}
			
		}
	}


	public function displaydataeducation(){
		if (isset($_POST['id']) && $_POST['job_ID']) {
			$id = $_POST['id'];
			$job_ID = $_POST['job_ID'];

			$data = mysqli_query($this->connect(), "SELECT * FROM education WHERE ID ='$id'");
			$countdata = mysqli_num_rows($data);
			if ($countdata>0) {
				$count = 1;
				while ($fetchdata = mysqli_fetch_assoc($data)) {
					?>
					<li>
						<div class="w-100 float-left">
							<span class="subtitle w-100"><?php echo $fetchdata['Institute_name']; ?>  <a href="profile_edit.php?eid=<?php echo $fetchdata['Education_id']; ?>&&euserid=<?php echo $fetchdata['ID']; ?>&&eeid=<?php echo $fetchdata['job_ID']; ?>">Edit</a>

								<a href="#" id="deleterecord" data-toggle="modal" data-target="#dataview<?php  echo $count; ?>">Remove</a>    </span>
							<span class="second_subtitle w-100 float-left"><?php echo $fetchdata['Qualification']; ?></span>
							<span class="second_subtitle w-100"><?php echo $fetchdata['Passing_of_Year']; ?></span>
	                          <span class="second_subtitle w-100 float-left"><?php echo $fetchdata['Job_location']; ?></span>
	                       </div>
	                    </li>

	                    <div id="dataview<?php  echo $count; ?>" class="modal fade" role="dialog">
		                  <div class="modal-dialog">

		                    <!-- Modal content-->
		                    <div class="modal-content">
		                      <div class="modal-body">
		    					Are you sure do you want to delete?                    
		                      </div>
		                      <div class="modal-footer">
		                      	<a href="delete.php?edid=<?php echo $fetchdata['Education_id']; ?>&&eduserid=<?php echo $fetchdata['ID']; ?>&&edeid=<?php echo $fetchdata['job_ID']; ?>" class="btn btn-default">Yes</a>
		                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
		                      </div>
		                    </div>

		                  </div>
		                </div>
					<?php
					$count++;
				}
						
			}else{
				?>
				

				<?php
			}
		}
	}

	public $edudata = array();
	public function editeducationfunction($id, $userid, $eid){
		$query = mysqli_query($this->connect(), "SELECT * FROM education WHERE Education_id='$id' && ID='$userid' && job_ID='$eid'");
		$count = mysqli_num_rows($query);
		if ($count>0) {
			$fetch = mysqli_fetch_assoc($query);

			$this->edudata[0] = $fetch['Institute_name'];
			$this->edudata[1] = $fetch['Qualification'];
			$this->edudata[2] = $fetch['Passing_of_Year'];
			$this->edudata[3] = $fetch['Job_location'];

		}

	}
}

$educationdata = new educationdata();
$educationdata->insertdataforeducation();
$educationdata->displaydataeducation();
?>
