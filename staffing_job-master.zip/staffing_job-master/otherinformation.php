<?php


require_once('database.php');

class otherinformation extends database
{
	
	public function otherinformationdata(){
		if (isset($_POST['job_ID']) && !empty($_POST['job_ID'])&& isset($_POST['current_location'])) {

			$id = $_POST['id'];
			$job_ID = $_POST['job_ID'];
			$current_location = $_POST['current_location'];
			$Preferred_location = $_POST['Preferred_location'];
			$lastsalary = $_POST['lastsalary'];
			$lastsalarythousand = $_POST['lastsalarythousand'];
			$expectingsalary = $_POST['expectingsalary'];
			$expectingsalarythousands = $_POST['expectingsalarythousands'];
			$address = $_POST['address'];


			$data = mysqli_query($this->connect(), "SELECT * FROM job_applied WHERE ID = '$id'");
			$count = mysqli_num_fields($data);
			if ($count>0) {
				mysqli_query($this->connect(), "INSERT INTO others_information (ID, job_ID, Current_location, Preferred_location, Last_salary, last_salary_thousand, Expecting_salary, expeted_salary_thousand, Address) VALUES ('$id', '$job_ID', '$current_location', '$Preferred_location', '$lastsalary', '$lastsalarythousand', '$expectingsalary', '$expectingsalarythousands', '$address')");
			}
		}else{
			$this->error[0] = "Please fill all fields";
		}
	}


	public function otherdisplaydataexperince(){

		$id = $_POST['id'];
		$job_ID = $_POST['job_ID'];

		$data = mysqli_query($this->connect(), "SELECT * FROM others_information WHERE ID ='$id'");
		$countdata = mysqli_num_rows($data);
		if ($countdata>0) {
			while ($fetchdata = mysqli_fetch_assoc($data)) {
				if (isset($fetchdata['Current_location'])) {
					?>
					<span class="subtitle w-100"><a href="" >Edit</a>
					<tr>
                        <td class="lable_text">Current Location </td>
                        <td class="infp_text"><?php echo $fetchdata['Current_location']; ?></td>
                    </tr>
					<?php
				}
				if (isset($fetchdata['Preferred_location'])) {
					?>
					<tr>
                        <td class="lable_text">Preferred Location</td>
                        <td class="infp_text"><?php echo $fetchdata['Preferred_location']; ?></td>
                    </tr>
					<?php
				}
				if (isset($fetchdata['Last_salary'])) {
					?>
					<tr>
                        <td class="lable_text">Last Salary </td>
                        <td class="infp_text"><?php echo $fetchdata['Last_salary'].".".$fetchdata['last_salary_thousand']." Lakhs per year"; ?></td>
                    </tr>
					<?php
				}
				if (isset($fetchdata['Expecting_salary'])) {
					?>
					<tr>
                        <td class="lable_text">Expecting Salary </td>
                        <td class="infp_text"><?php echo $fetchdata['Expecting_salary'].".".$fetchdata['expeted_salary_thousand']." Lakhs per year"; ?></td>
                    </tr>
					<?php
				}
				if (isset($fetchdata['Address'])) {
					?>
					<tr>
                        <td class="lable_text">Address </td>
                        <td class="infp_text"><?php echo $fetchdata['Address']; ?></td>
                    </tr>
					<?php
				}
			}
					
		}else{
			?>
			

			<?php
		}
	}
}


$otherinformation = new otherinformation();
$otherinformation->otherinformationdata();
$otherinformation->otherdisplaydataexperince();
?>