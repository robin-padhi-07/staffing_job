<?php
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
?>
<?php
	require_once('database.php'); 
	$query="select * from job_list";
    //Getting the id of Individual Jobs 
	if(isset($_GET["id"]))
	{
		$query="SELECT * FROM job_list WHERE id = '".$_GET["id"]."' LIMIT 1";
		$result=mysqli_query($link, $query);
		foreach($result as $row)
		{
			$event_name = $row['job_name'];
			$event_des = $row['company_name'];
			$location = $row['location'];
			//$image = $row['image'];
			$image = '<img src="admin/upload/'.$row["image"].'"  />';
            $image_not = '<img src="admin/upload/no_image.png"  />';
            
            //Storing this Value from Above Table, so we can send this data to From Element
            $job_title =$row["job_name"];
            $job_company_name =$row["company_name"];  
            $job_location = $row['location'];
		}
	}
?>
<?php include ("header.php");?>
	<div class="container main_wrapper">
    <div class="col-md-4 float-left col-12">
            <div class="sidebar mt_20 desktop_view float-left">
            <h1 class="primery_title">Apply this job </h1>
            <?php 
                require_once('database.php'); 
                $user=$_SESSION["username"];
                //echo $user;             
                $sql = "SELECT * from users where username ='$user'";
                $results = mysqli_query($link, $sql);
                $rows = mysqli_fetch_array($results);
                //Getting Loged-in User ID then Store this in this below $ID Variable
                $id = $rows["id"];


                if (isset($_POST['submit'])){
                    //$strsql = "INSERT INTO post(job_title,job_company_name,user_id,job_location) VALUES('$job_title','$job_company_name','$id','$job_location')";
                    $strsql  = "INSERT INTO `job_applied` (`job_title`, `job_company_name`, `user_id`, `job_location`) VALUES ( '{$job_title}', '{$job_company_name}', '{$id}', '{$job_location}')";
                    //print_r($strsql);
                    $result=mysqli_query($link, $strsql);
                    
                }
            ?>
                <form class="needs-validation" action="" method="POST">
                    <input type="submit" name="submit" class="primary_btn" value="Apply Now" />
                    <!-- <input type="submit" id="send_post" name="submit" class="btn btn-primary"> -->
                </form>
            </div>
        </div>
        <!-- ===  OL_MD 4 right side section end here ========== -->
        
        <div class="col-md-8 float-left col-12 no-padding">
            <div class="wrapper">
                <div class="common_box mt_20 float-left gradient_bg pb_30 pt_30">

                    <div class="job_container" style="background: transparent; border: none; color: #fff !important; padding: 0;s">
                        <div class="job_img">
							<?php 
							if($row["image"] != '')
							{
								echo $image;
							}
							else{
								echo $image_not;
							}
							?>
                        </div>
                        <div class="job_caption">
                            <span class="font_20 mb_10 text-white"> <?php echo $row['job_name']; ?> </span>
							<span class="second_subtitle text-white"> <?php echo $row['company_name']; ?>  </span>
							<div class="text-white mt_10">
                        	<span class="mr_10"><span class="icon_set icon-wall-clock mr_10"></span> <?php echo $row['job_type']; ?> </span>
                        	<span class="ml_10"><span class="icon_set icon-placeholders-1 mr_10"></span><?php echo $row['location']; ?></span>
                    </div>
                        </div>
                    </div>
                    
                </div>
                <div class="common_box mt_10 float-left">
                    <h1 class="section_title">Description </h1>
                    <p class="w-100 float-left mt_15 pr_20">
                    <?php echo $row['job_des']; ?>
                    </p>

                </div>
                <!--  ================== Experience END -->

                <div class="common_box mt_10 float-left">
                    <h1 class="section_title">Others Information </h1>

                    <table class="table spec_table">
                        <tr>
                            <td class="lable_text">Accommodation </td>
                            <td class="infp_text"> <?php echo $row['accommodation']; ?> </td>
                        </tr>
                        <tr>
                            <td class="lable_text">Experience </td>
                            <td class="infp_text"><?php echo $row['exp']; ?> Years</td>
                        </tr>
                        <tr>
                            <td class="lable_text"> Monthly Off </td>
                            <td class="infp_text"><?php echo $row['monthly_off']; ?></td>
                        </tr>
                        <tr>
                            <td class="lable_text">Salary</td>
                            <td class="infp_text"><?php echo $row['salary']; ?></td>
                        </tr>
                       
                    </table>
                </div>
                <!--  ================== Other Information END -->
            </div>
		</div> <!-- ====  COL_MD 8 right side section end here ========== -->
	</div>


    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
    'use strict';
    window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
        });
    }, false);
    })();
</script>

    <?php include ("footer.php");?>
    

