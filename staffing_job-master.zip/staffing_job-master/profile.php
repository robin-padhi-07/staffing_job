<?php
    // Initialize the session
    session_start();
 
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
?>
<?php
// session_start();
    include ("header.php");
    require_once('database.php');
    require_once('profile_page.php'); 
    require_once('file_upload.php');

    $updatedataimg = new updatedataimg();
$profiledisplay = new profiledisplay();
$profiledisplay->profiledisplaydata($_SESSION['id']);
$profiledisplay->displaydatatat($_SESSION['id']);
if (isset($_POST['submit4'])) {
    $updatedataimg->uploadfile2();
}
$updatedataimg->viewimgpro($_SESSION['id'])
?>

<div class="container main_wrapper">
<div class="col-md-4 float-left col-12">
<div class="sidebar mt_20 desktop_view float-left">
    <span style="position: absolute; right: 20px; top: 10px; font-size: 14px;"> <a href="profile_edit.php">Edit</a> </span>
    <img src="upload/<?php echo $updatedataimg->dataimg1[0]; ?>" class="round_img">

    <form id="uploadForm" method="post" enctype="multipart/form-data">
        <input name="filess" type="file" class="inputFile" />
        <input type="hidden" id="id" value="<?php echo $_SESSION["id"]; ?>" name="id">
        <input type="hidden" value="<?php if(empty($editprofile->data[0])){
            }else{
                echo $editprofile->data[0];
            } ?>" name="job_ID" id="job_ID" class="form-control" id="validationCustom03">
            <input type="submit" value="Submit" name="submit4" class="btnSubmit" />
        </form>

    <span class="primery_title float-left pt_5"><?php echo $profiledisplay->datadisplay[0]; ?></span>
    <?php if (isset($profiledisplay->datadisplay[1])) {
        ?>
        <span class="second_subtitle float-left"><?php echo $profiledisplay->datadisplay[1]; ?></span>
        <?php
    }
    ?>
    
</div>

</div> <!-- ===  OL_MD 4 right side section end here ========== -->
    <div class="col-md-8 float-left col-12 no-padding">
        <div class="wrapper">
            <div class="common_box mt_20 float-left gradient_bg pb_30 pt_30">
                <a href="profile_edit.php" style="color: #fff; text-decoration: none;position: absolute; right: 20px; top: 15px; font-size: 14px;"> 
                    <span class="icon-document icon_set"></span> Edit </a> 

                <img src="upload/<?php echo $updatedataimg->dataimg1[0]; ?>" class="round_img_big">
                <span class="primery_title float-left text-center text-white w-100"><?php echo $profiledisplay->datadisplay[0]; ?></span>
                <?php if (isset($profiledisplay->datadisplay[1])) {
                    ?>
                    <span class="font_14 mb_5 float-left text-center text-white w-100"><?php echo $profiledisplay->datadisplay[1]; ?></span>
                    <?php
                }
                if (isset($profiledisplay->datadisplay[2])) {
                    ?>
                <span class="font_14 mb_10 float-left text-center text-white w-100"><?php echo $profiledisplay->datadisplay[2]; ?></span>
                <?php
            }
                ?>
                <?php if (isset($profiledisplay->datadisplay[3]) && isset($profiledisplay->datadisplay[5])) {
                   ?>
                   <div class="block_center text-white mt_10">
                    <span class="mr_10"><span class="icon_set icon-wall-clock mr_10"></span><?php echo $profiledisplay->datadisplay[3]; ?> years <?php echo $profiledisplay->datadisplay[4]; ?> Months</span> 
                    <span class="ml_10"><span class="icon_set icon-placeholders-1 mr_10"></span><?php echo $profiledisplay->datadisplay[5]; ?></span> 
                </div>
                   <?php
                } ?>
                
            </div>
            <div class="common_box mt_10 float-left">
                <h1 class="section_title">Experience </h1>
                
                <ul class="cpmmon_ul">
                    <?php $profiledisplay->displayprofiledata($_SESSION['id']); ?>
                </ul>
            </div> <!--  ================== Experience END -->
            <div class="common_box mt_10 float-left">
                <h1 class="section_title">Education </h1>
                
                <ul class="cpmmon_ul">
                    <?php $profiledisplay->displayprofiledata1($_SESSION['id']); ?>
                </ul>
            </div> <!--  ================== Education END -->
            <div class="common_box mt_10 float-left">
                <h1 class="section_title">Others Information </h1>
                
                <table class="table spec_table">
                    <?php $profiledisplay->displayprofiledata2($_SESSION['id']); ?>
                    
                </table>                 
            </div> <!--  ================== Other Information END -->
            <div class="common_box mt_10 float-left mb_30">
                <h1 class="section_title mb_15">Proof of identification  </h1>
                <div class="job_container">
                    <div class="job_img">
                        <?php $updatedataimg->viewimg($_SESSION['id']); ?>
                        <?php if (isset($updatedataimg->dataimg[0])) {
                            ?>
                            <img src="upload/<?php echo $updatedataimg->dataimg[0]; ?>" class="">
                            <?php
                        }
                        ?>
                        
                    </div>
                </div>
                <div class="job_container">
                    <div class="job_img">
                        <?php if (isset($updatedataimg->dataimg[1])) {
                            ?>
                        <img src="upload/<?php echo $updatedataimg->dataimg[1]; ?>" class="">
                        <?php
                    }
                    ?>

                    </div>
                </div>
            </div>
  

        </div>
    </div><!-- ====  COL_MD 8 right side section end here ========== -->
    
    
</div>



    <script src="assets/js/jquery-3.4.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="assets/js/owl.carousel.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>    