<?php
    // Initialize the session
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    } 
?>
<?php
    include ("header.php");
    require_once('database.php');
?>

 <div class="container main_wrapper">


<div class="col-md-12 float-left col-12 no-padding">
<img src="assets/images/slider_03.png" class="w-100">
</div>

<div class="col-md-8 float-left col-12">
    <div class="">

        <div class="col-md-6 col-6 float-left pl_0 mt_20">
            <div class="common_box float-left">
                <span class="text-center float-left w-100" style="font-size:30px;">232</span>
                <span class="second_subtitle text-center float-left w-100"> Jobs Applied </span>
            </div>
        </div>
        <div class="col-md-6 col-6 float-left pr_0 mt_20">
            <div class="common_box float-left">
                <span class="text-center float-left w-100" style="font-size:30px;">23</span>
                <span class="second_subtitle text-center float-left w-100"> Jobs Applied </span>
            </div>
        </div>

        <h1 class="section_title mt_20 mb_15">Recently Posted </h1>
        <ul class="jobs">
            <li>
                <div class="job_container">
                    <div class="job_img">
                        <img src="assets/images/job_1.png" class="">
                    </div>
                    <div class="job_caption">
                        <span class="primery_title">Food and Beverage Vocational Trainer</span>
                        <span class="second_subtitle">BISWA GOURI CHARITABLE TRUST </span>
                        <span class="">Bangalore   <span class="dots">•</span> 2 days ago</span>
                    </div>
                </div>
            </li>
            <li>
                <div class="job_container">
                    <div class="job_img">
                        <img src="assets/images/job_2.png" class="">
                    </div>
                    <div class="job_caption">
                        <span class="primery_title">Food and Beverage Vocational Trainer</span>
                        <span class="second_subtitle">BISWA GOURI CHARITABLE TRUST </span>
                        <span class="">Bangalore</span> <span class="">2 days ago</span>
                    </div>
                </div>
            </li>
        </ul>

    </div>
</div>
<!-- ====  COL_MD 8 right side section end here ========== -->


</div>






<?php include ("footer.php");?>