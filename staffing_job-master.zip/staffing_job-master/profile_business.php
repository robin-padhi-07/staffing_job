<?php
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
?>

<?php include ("header.php");?>
	<div class="container main_wrapper">
    <div class="col-md-4 float-left col-12 mobile_view no-padding">
        <img src="assets/images/slider_01.svg" class="w-100">
    </div>

    <div class="col-md-4 float-left col-12 desktop_view no-padding">
            <div class="mt_20 float-left">
            <img src="assets/images/slider_02.svg" style="width: 330px !important; margin-top: -12px;">
            
            <?php
                require_once('database.php'); 
                $sqlZ = "SELECT * from profile_business";
                $resultss = mysqli_query($link, $sqlZ);
                $rowsss = mysqli_fetch_array($resultss);
                $company_names = $rowsss["business_name"];
                //echo $company_names;
            ?>
               
            <?php 
                require_once('database.php'); 
                $user=$_SESSION["username"];
                //echo $user;             
                $sql = "SELECT * from users where username ='$user'";
                $results = mysqli_query($link, $sql);
                $rows = mysqli_fetch_array($results);
                //Getting Loged-in User ID then Store this in this below $ID Variable
                $id = $rows["id"];


                if (isset($_POST['submit'])){
                    //This Variable take value from Form element
                    $job_name = $_POST['job_name'];
                    $company_name = $_POST['company_name'];
                    $job_des = $_POST['job_des'];
                    $location = $_POST['city'];
                    $accommodation = $_POST['accommodation'];
                    $job_type = $_POST['job_type'];
                    $exp = $_POST['exp'];
                    $monthly_off = $_POST['monthly_off'];
                    $salary = $_POST['salary'];
                    $image = $_POST['image'];

                    //$strsql = "INSERT INTO job_list(job_name,job_company_name,user_id,job_location) VALUES('$job_title','$job_company_name','$id','$job_location')";
                    $strsql  = "INSERT INTO `job_list` (`job_name`, `company_name`, `company_id`, `job_des`, `image`, `location`, `accommodation`, `job_type`, `exp`, `monthly_off`, `salary`, `updated_at`, `created_at`) 
                    VALUES ( '{$job_name}', '{$company_name}', '{$id}', '{$job_des}', '{$image}', '{$location}', '{$accommodation}', '{$job_type}', '{$exp}', '{$monthly_off}', '{$salary}',now(),now())";
                    //print_r($strsql);
                    $result=mysqli_query($link, $strsql);
                    
                }
            ?>
            </div>
        </div>
        <!-- ===  OL_MD 4 right side section end here ========== -->
        <div class="col-md-8 float-left col-12 no-padding ">
            <div class="wrapper">
                <div class="common_box mt_10 float-left mt_20 pb_60">
                    <h1 class="section_title w-100">Post a Job </h1>
                    <h1 class="subtitle">Fill this below form to post your requirment</h1>

                    <form class="needs-validation w-100 float-left mt_20" action="" method="POST">

                    <div class="row">
                    <div class="col-md-6 float-left col-12 mb_20">
                        <label for="">Job Title</label>
                        <input type="text" name="job_name" class="form-control" id="" placeholder="e.g Kitchen Manager" required>
                    </div> 
                    <div class="col-md-6 float-left col-12 mb_20">
                        <label for="">Company_name</label>
                        <input type="text" name="company_name" class="form-control" value="<?php echo $rowsss["business_name"]; ?>" placeholder="Name" readonly>
                    </div>
                    <div class="col-md-12 float-left col-12 mb_20">
                        <label for="">Job Description </label>
                        <textarea type="text" name="job_des" class="form-control" rows="4" style="height: auto !important;"></textarea>
                        
                    </div> 
                    <div class="col-md-6 float-left col-6 mb_20">
                         <label for="">State </label>
                        <input type="hidden" name="country" id="countryId" value="IN"/>
                        <select name="state" class="form-control states order-alpha" id="stateId">
                            <option value="">Select State</option>
                        </select>
                    </div>
                    <div class="col-md-6 float-left col-6 mb_20">
                        <label for="">Location </label>
                        <select name="city" id="cityId" class="form-control cities order-alpha">
                            <option value="">Select City</option>
                        </select>
                    </div>

                    <div class="col-md-4 float-left col-6 mb_20">
                        <label for="">Accommodation </label>
                        <select name="accommodation" class="form-control">
                            <option selected disabled value="">Choose...</option>
                            <option value="Yes"> Yes </option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <div class="col-md-4 float-left col-6 mb_20">
                        <label for="">Job type </label>
                        <select name="job_type" class="form-control">
                            <option selected disabled value="">Choose...</option>
                            <option value="Full Time"> Full Time </option>
                            <option value="Part Time">Part Time</option>
                        </select>
                    </div>
                    <div class="col-md-4 float-left col-6 mb_20">
                        <label for="">Experiance </label>
                        <input type="number" name="exp" class="form-control"  placeholder="Total years">
                    </div> 
                    <div class="col-md-4 float-left col-6 mb_20">
                        <label for="">Monthly_off </label>
                        <input type="number" name="monthly_off" class="form-control"  placeholder="Booking date">
                    </div> 
                    <div class="col-md-4 float-left col-6 mb_20">
                        <label for="">Salary </label>
                        <input type="text" name="salary" class="form-control"  placeholder="Booking date">
                    </div> 
                    <div class="col-md-6 float-left col-6 mb_20">
                        <label for="">Images </label>
                        <input type="text" name="image" class="form-control"  placeholder="Booking date">
                    </div> 

                    </div> <!--End of Row-->
                    <!-- <button type="submit" class="btn btn-success">Submit </button> -->
                    <input type="submit" name="submit" class="primary_btn" value="Post Now" />
                    <!-- <input type="submit" id="send_post" name="submit" class="btn btn-primary"> -->
                
                    <div class="w-100 float-left">
                        <!-- <input type="hidden" name="country" id="countryId" value="IN"/>
                        <select name="state" class="states order-alpha" id="stateId">
                            <option value="">Select State</option>
                        </select>
                        <select name="city" class="cities order-alpha" id="cityId">
                            <option value="">Select City</option>
                        </select> -->
                    </div>
                </form>
 
                </div>
                <!--  ================== Description END -->
            </div>
		</div> <!-- ====  COL_MD 8 right side section end here ========== -->
	</div>


    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
    'use strict';
    window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
        });
    }, false);
    })();
</script>



    <?php include ("footer.php");?>
    <script src="//geodata.solutions/includes/statecity.js"></script>


    

