<?php
    // Initialize the session
    session_start();
 
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
?>
<?php
// session_start();

include_once('edit_profile_validation.php'); 
include_once('education.php');
require_once('delete.php');
require_once('profile_page.php');
require_once('file_upload.php');
$updatedataimg = new updatedataimg();

if (isset($_POST['submit2'])) {
    $updatedataimg->uploadfile();
}
if (isset($_POST['submit3'])) {
    $updatedataimg->uploadfile1();
} 
$profiledisplay = new profiledisplay();
$profiledisplay->profiledisplaydata($_SESSION['id']);
$delete = new daleterecord();

$editprofile->displaydata($_SESSION['id']);
if (isset($_GET['id']) && isset($_GET['userid']) && isset($_GET['eid'])) {
    $id = $_GET['id'];
    $userid = $_GET['userid'];
    $eid = $_GET['eid'];
    $editprofile->editfunction($id, $userid, $eid);
}

if (isset($_GET['eid']) && isset($_GET['euserid']) && isset($_GET['eeid'])) {
    $eid = $_GET['eid'];
    $euserid = $_GET['euserid'];
    $eeid = $_GET['eeid'];
    $educationdata->editeducationfunction($eid, $euserid, $eeid);
}

$updatedataimg->viewimgpro($_SESSION['id']);

include ("header.php");
  
?>


<div class="container main_wrapper">
<div class="col-md-4 float-left col-12">
<div class="sidebar mt_20 desktop_view float-left">
    <span style="position: absolute; right: 20px; top: 10px; font-size: 14px;"> <a href="">Edit</a> </span>
    <img src="upload/<?php echo $updatedataimg->dataimg1[0]; ?>" class="round_img">
    <span class="primery_title float-left pt_5"><?php echo $profiledisplay->datadisplay[0]; ?></span>
    <?php if (isset($profiledisplay->datadisplay[1])) {
        ?>
        <span class="second_subtitle float-left"><?php echo $profiledisplay->datadisplay[1]; ?></span>
        <?php
    }
    ?>
    
</div>

</div> <!-- ===  OL_MD 4 right side section end here ========== -->
    <div class="col-md-8 float-left col-12 no-padding">
        <div class="wrapper">
            <div class="common_box mt_20 float-left  pb_30 pt_30">
                <form action="" class="needs-validation w-100 pt_10 float-left" id="form1" novalidate>
                    <div class="col-md-6 float-left col-12 mb_20">
                        <label for="validationCustom03">Full Name</label>
                        <input type="text" value="<?php if(empty($editprofile->data[1])){

                        }else{
                            echo $editprofile->data[1];
                        } ?>" name="fullname" class="form-control" id="validationCustom03" required placeholder="Full name">
                        <div class="invalid-feedback">Please provide a valid Name. </div>
                    </div> 
                    <div class="col-md-6 float-left col-12 mb_20">
                        <label for="validationCustom03">Email</label>
                        <input type="email" value="<?php if(empty($editprofile->data[2])){

                        }else{
                            echo $editprofile->data[2];
                        } ?>" name="email" class="form-control" id="validationCustom03 validationCustom04" required placeholder="Email address">
                        <div class="invalid-feedback">Please provide a valid Name. </div>
                    </div> 
                    <div class="col-md-6 float-left col-12  mb_20">
                        <label for="validationCustom03">Phone</label>
                        <input type="phone" value="<?php if(empty($editprofile->data[3])){

                        }else{
                            echo $editprofile->data[3];
                        } ?>" name="number" class="form-control" id="validationCustom03" required placeholder="Phone number">
                        <div class="invalid-feedback">Invalid Password </div>
                    </div>
                    <div class="col-md-6 float-left col-12 mb_20">
                        <label for="validationCustom03">Location</label>
                        <input type="text" value="<?php if(empty($editprofile->data[4])){

                        }else{
                            echo $editprofile->data[4];
                        } ?>" name="location" class="form-control" id="validationCustom03" required placeholder="City">
                        <input type="hidden" value="<?php echo $_SESSION["id"]; ?>" name="id">
                        
                    </div>  

                    
                    <button class="primary_btn mb_20" name="firstbutton" id="userinfo" type="submit"><?php if (empty($editprofile->data[0])) {
                        echo "Save";
                    }else{
                        echo "UPDATE";
                    } ?></button>
                </form>
            </div>
            <!-- =============== Experience  ==== ========================-->
            <div class="common_box mt_10 float-left">
                <h1 class="section_title w-100">Experience </h1>
                <form action="" class="needs-validation w-100 pt_10 float-left" id="form2" novalidate>
                    <div class="col-md-12 float-left col-12 mb_20">
                        <label for="validationCustom03">Company name</label>
                        <input type="text" value="<?php if(empty($editprofile->fetchdata[0])){

                        }else{
                            echo $editprofile->fetchdata[0];
                        } ?>" name="Company_name" id="Company_name" class="form-control" id="validationCustom03" required placeholder="Company name">
                        <div class="invalid-feedback">Company name required </div>
                    </div> 
                    <div class="col-md-6 float-left col-12 mb_20">
                        <label for="validationCustom03">Position Name</label>
                        <select class="form-control abc" name="position_name" id="exampleFormControlSelect1">
                            <option value="Junior Chefs">Junior Chefs</option>
                            <option value="Senior Chefs">Senior Chefs</option>
                            <option value="Master">Master</option>
                            <option value="Head of Cook">Head of Cook</option>
                            <option value="Jn Cook">Jn Cook</option>
                          </select>
                    </div> 
                    <div class="col-md-3 float-left col-12 mb_20">
                        <label for="validationCustom03">Year of exp</label>
                        <select class="form-control years" name="yearsofexperience" id="exampleFormControlSelect1">
                            <option value="01">01</option>
                            <option value="02">02</option>
                            <option value="03">03</option>
                            <option value="04">04</option>
                            <option value="05">05</option>
                          </select>
                    </div> 
                    <div class="col-md-3 float-left col-12 mb_20">
                        <label for="validationCustom03">Month Name</label>
                        <select class="form-control month" name="month_name" id="exampleFormControlSelect1">
                            <option value="01">01</option>
                            <option value="02">02</option>
                            <option value="03">03</option>
                            <option value="04">04</option>
                            <option value="05">05</option>
                          </select>
                    </div> 
                    <div class="col-md-6 float-left col-12 mb_20">
                        <label for="validationCustom03">Job Location</label>
                        <select class="form-control location" name="job_location" id="exampleFormControlSelect1">
                            <option value="Bangalore">Bangalore</option>
                            <option value="Mysore">Mysore</option>
                            <option value="Kerela">Kerela</option>
                            <option value="Mumbai">Mumbai</option>
                            <option value="Chennai">Chennai</option>
                          </select>
                    </div> 
                    <div class="col-md-6 float-left col-12 mb_20">
                        <input type="hidden" id="id" value="<?php echo $_SESSION["id"]; ?>" name="id">
                        <input type="hidden" value="<?php if(empty($editprofile->data[0])){

                        }else{
                            echo $editprofile->data[0];
                        } ?>" name="job_ID" id="job_ID" class="form-control" id="validationCustom03" required placeholder="City">
                        <input type="hidden" id="Experience_id" value="<?php if(isset($_GET['id'])){ echo $_GET['id']; } else{ echo ""; } ?>" name="Experience_id">
                        <button type="submit" class="btn mb_20 mt_20 btn-primary"> <?php if (isset($_GET['id']) && isset($_GET['userid']) && isset($_GET['eid'])) {
                                 echo "UPDATE";
                                }else{
                                    echo "SAVE";
                                } ?></button>
                    </div>
                </form>
                <ul class="cpmmon_ul datadisplay">
                    
                </ul>
            </div> <!--  ================== Experience END -->
            
            <!-- =============== Education  ==== ========================-->
            <div class="common_box mt_10 float-left">
                <h1 class="section_title w-100">Education </h1>
                
                <form action="" class="needs-validation w-100 pt_10 float-left" id="form3" novalidate>
                
                <div class="col-md-12 float-left col-12 mb_20">
                    <label for="validationCustom03">Institute name</label>
                    <input type="text" value="<?php if(empty($educationdata->edudata[0])){

                        }else{
                            echo $educationdata->edudata[0];
                        } ?>" name="Institutename" class="form-control Institutename" id="validationCustom03" required placeholder="Instituten name">
                    <div class="invalid-feedback">Company name required </div>
                </div> 
                <div class="col-md-5 float-left col-12 mb_20">
                    <label for="validationCustom03">Qualification</label>
                    <select class="form-control classdata" name="Qualification" id="exampleFormControlSelect1">
                        <option value="10th">10th </option>
                        <option value="12th">12th </option>
                        <option value="BBA">BBA</option>
                        <option value="MBA">MBA</option>
                        <option value="Engineering">Engineering</option>
                    </select>
                </div> 
                <div class="col-md-3 float-left col-12 mb_20">
                    <label for="validationCustom03">Passing of Year</label>
                    <select class="form-control Passingyears" name="Passingyears" id="exampleFormControlSelect1">
                        <option value="2020">2020</option>
                        <option value="2219">2219</option>
                        <option value="2323">2323</option>
                        <option value="2323">2323</option>
                        <option value="2323">2323</option>
                    </select>
                </div> 
                <div class="col-md-4 float-left col-12 mb_20">
                    <label for="validationCustom03">Job Location</label>
                    <select class="form-control joblocationdata" name="joblocation" id="exampleFormControlSelect1">
                        <option value="Bangalore">Bangalore</option>
                        <option value="Mysore">Mysore</option>
                        <option value="Kerela">Kerela</option>
                        <option value="Mumbai">Mumbai</option>
                        <option value="Chennai">Chennai</option>
                    </select>
                </div>
                
            </div> 
            <input type="hidden" id="id" value="<?php echo $_SESSION["id"]; ?>" name="id">
            <input type="hidden" value="<?php if(isset($_GET['eid'])){ echo $_GET['eid']; } else { echo ""; } ?>" name="education_id" id="education_id">
            <input type="hidden" value="<?php if(empty($editprofile->data[0])){

                        }else{
                            echo $editprofile->data[0];
                        } ?>" name="job_ID" id="job_ID" class="form-control" id="validationCustom03" required placeholder="City">
            <button type="submit" class="btn mb_20 mt_10 btn-primary"><?php if (empty($educationdata->edudata[0])) {
                        echo "Save";
                    }else{
                        echo "UPDATE";
                    } ?></button>
        </form>
            <ul class="cpmmon_ul datadisplay1">
                
            </ul>
            </div> <!--  ================== Experience END -->

            <div class="common_box mt_10 float-left">
                <h1 class="section_title w-100">Certification </h1>
            </div>

            <div class="common_box mt_10 float-left">
                <h1 class="section_title w-100">Others Information </h1>
                
                    <form action="" id="form4" class="needs-validation w-100 pt_10 float-left" novalidate>
                        <!-- <div class="col-md-6 float-left col-12 mb_20">
                            <label for="validationCustom03">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" id="validationCustom03" required>
                            <div class="invalid-feedback">Enter validate date</div>
                        </div> 
                        <div class="col-md-6 float-left col-12 mb_20">
                            <label for="validationCustom03">Gender</label>
                            <select class="form-control" name="gender" id="exampleFormControlSelect1">
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <div class="invalid-feedback">Please provide a valid Name. </div>
                        </div>  -->

                        <div class="col-md-6 float-left col-12 mb_20">
                            <label for="validationCustom03">Current Location</label>
                            <select class="form-control" name="current_location" id="exampleFormControlSelect1">
                                <option value="Bangalore">Bangalore</option>
                                <option value="Mysore">Mysore</option>
                                <option value="Kerela">Kerela</option>
                                <option value="Mumbai">Mumbai</option>
                                <option value="Chennai">Chennai</option>
                            </select>
                            <div class="invalid-feedback">Select City name </div>
                        </div> 
                        <div class="col-md-6 float-left col-12 mb_20">
                            <label for="validationCustom03">Preferred Location</label>
                            <select class="form-control" name="Preferred_location" id="exampleFormControlSelect1">
                                <option value="Bangalore">Bangalore</option>
                                <option value="Mysore">Mysore</option>
                                <option value="Kerela">Kerela</option>
                                <option value="Mumbai">Mumbai</option>
                                <option value="Chennai">Chennai</option>
                            </select>
                            <div class="invalid-feedback">Please provide a valid Name. </div>
                        </div> 
                        <div class="col-md-6 float-left col-12  mb_20">
                            <label for="validationCustom03" class="w-100">Last Salary (Yearly)</label>
                            <select class="form-control col-md-6 pr_0 float-left" name="lastsalary" id="exampleFormControlSelect1">
                                <option value="0">0 Lakhs</option>
                                <option value="1">1 Lakhs</option>
                            </select>
                            <select class="form-control col-md-6 no-padding float-left" id="exampleFormControlSelect1" name="lastsalarythousand">
                                <option value="10">10 Thousand</option>
                                <option value="20">20 Thousand</option>
                            </select>
                            <div class="invalid-feedback">Invalid Password </div>
                        </div>
                        <div class="col-md-6 float-left col-12 mb_20">
                            <label for="validationCustom03" class="w-100">Expecting Salary</label>
                            <select class="form-control col-md-6 pr_0 float-left" name="expectingsalary" id="exampleFormControlSelect1">
                                <option value="0">0 Lakhs</option>
                                <option value="1">1 Lakhs</option>
                            </select>
                            <select class="form-control col-md-6 no-padding float-left" id="exampleFormControlSelect1" name="expectingsalarythousands">
                                <option value="10">10 Thousand</option>
                                <option value="20">20 Thousand</option>
                            </select>
                            <div class="invalid-feedback">Invalid Password </div>
                        </div>  
                        <div class="col-md-12 float-left col-12 mb_20">
                            <label for="exampleFormControlTextarea1">Address</label>
                            <textarea class="form-control" id="address" name="address" id="exampleFormControlTextarea1" rows="3"></textarea>
                          </div>
                        
                    <input type="hidden" id="id" value="<?php echo $_SESSION["id"]; ?>" name="id">
                    <input type="hidden" value="<?php if(empty($editprofile->data[0])){

                        }else{
                            echo $editprofile->data[0];
                        } ?>" name="job_ID" id="job_ID" class="form-control" id="validationCustom03" required placeholder="City">
            <button type="submit" class="btn mb_20 mt_10 btn-primary" value="<?php /*if (empty($editprofile->data[0])) {
                        echo "Save";
                    }else{
                        echo "UPDATE";
                    }*/ ?>">SAVE</button>         
                    </form>
                </div><!--End of Row-->
                <table class="table spec_table displaytabledata">
                    
                </table>                 
            </div> <!--  ================== Other Information END -->
            <div class="common_box mt_10 float-left mb_30">
                <h1 class="section_title mb_15">Proof of identification  </h1>
                <div class="job_container">
                    <div class="job_img" id="targetLayer">
                        <?php $updatedataimg->viewimg($_SESSION['id']); ?>
                        <img src="upload/<?php echo $updatedataimg->dataimg[0]; ?>" class="">
                    </div>
                    <div class="job_caption">
                        <span class="primery_title">Addhar Card</span>
                        <span class="second_subtitle">1980 18229 929230 </span>
                    </div>
                    <form id="uploadForm" method="post" enctype="multipart/form-data">
                        
                        <label>Upload Image File:</label><br/>
                        
                        <input name="file" type="file" class="inputFile" />
                        
                        <input type="hidden" id="id" value="<?php echo $_SESSION["id"]; ?>" name="id">
                        <input type="hidden" value="<?php if(empty($editprofile->data[0])){

                        }else{
                            echo $editprofile->data[0];
                        } ?>" name="job_ID" id="job_ID" class="form-control" id="validationCustom03">

                        
                        <input type="submit" value="Submit" name="submit2" class="btnSubmit" />
                    </form>
                </div>
                <div class="job_container">
                    <div class="job_img">
                        <img src="upload/<?php echo $updatedataimg->dataimg[1]; ?>" class="">
                    </div>
                    <div class="job_caption">
                        <span class="primery_title">Pan Card</span>
                        <span class="second_subtitle">1980 18229 929230 </span>
                    </div>
                    <form id="uploadForm1" method="post" enctype="multipart/form-data">
                        
                        <label>Upload Image File:</label><br/>
                        
                        <input name="files" type="file" class="inputFile" />
                        
                        <input type="hidden" id="id" value="<?php echo $_SESSION["id"]; ?>" name="id">
                        <input type="hidden" value="<?php if(empty($editprofile->data[0])){

                        }else{
                            echo $editprofile->data[0];
                        } ?>" name="job_ID" id="job_ID" class="form-control" id="validationCustom03">

                        
                        <input type="submit" value="Submit" name="submit3" class="btnSubmit" />
                    </form>
                </div>
            </div>
  

        </div>
    </div><!-- ====  COL_MD 8 right side section end here ========== -->
    
    
</div>



    <script src="assets/js/jquery-3.4.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="assets/js/owl.carousel.js"></script>
    <script src="assets/js/main.js"></script>

    <script>


    var id = $("#id").val();
    var job_ID = $("#job_ID").val();
      $(function () {

        $('#form1').on('submit', function (e) {

          e.preventDefault();
          var name = $("#validationCustom03").val();
          var email = $("#validationCustom04").val();
          if (id!="" && job_ID!="") {
            if (name!="" && email != "") {
                $.ajax({
                    type: 'post',
                    url: 'edit_page.php',
                    data: $('form').serialize(),
                    success: function (data) {
                      alert('Submit successfully');
                    }
                });
            }else{
                alert("Please fill all fields");
            }
          }else{
              if (name!="" && email != "") {
                $.ajax({
                    type: 'post',
                    url: 'edit_profile_validation.php',
                    data: $('form').serialize(),
                    success: function (data) {
                      alert('Submit successfully');
                    }
                });
            }else{
                alert("Please fill all fields");
            }
        }

        });





        /*second form*/



        $('#form2').on('submit', function (e) {

          e.preventDefault();
          var Company_name = $("#Company_name").val();
          var Experience_id = $("#Experience_id").val();
          if (Company_name!="") {
            if (Experience_id!="") {
                $.ajax({
                    type: 'post',
                    url: 'edit_page.php',
                    data: $('form').serialize(),
                    success: function (data) {
                      $(".datadisplay").html(data);
                      alert('Successfully Updated');
                      window.location.href = "profile_edit.php#form2";
                      $("#form2").trigger("reset");
                    }
                });
            }else{
                $.ajax({
                    type: 'post',
                    url: 'edit_profile_validation.php',
                    data: $('form').serialize(),
                    success: function (data) {
                        alert('Submit successfully');
                      $(".datadisplay").html(data);
                      $("#form2").trigger("reset");
                    }
                });
            }
        }else{
            alert("Please fill all fields");
        }

        });


        $('#form3').on('submit', function (e) {

          e.preventDefault();
          var Institutename = $(".Institutename").val();
          var education_id = $("#education_id").val();

          if (Institutename!="") {
            if (education_id != "") {
                $.ajax({
                    type: 'post',
                    url: 'edit_page.php',
                    data: $('form').serialize(),
                    success: function (data) {
                        alert('Successfully Updated');
                        window.location.href = "profile_edit.php#form3";
                    
                        $(".datadisplay1").html(data);
                        $("#form3").trigger("reset");
                    }
                });
            }else{
                $.ajax({
                    type: 'post',
                    url: 'education.php',
                    data: $('form').serialize(),
                    success: function (data) {
                        alert('Submit successfully');
                      $(".datadisplay1").html(data);
                      $("#form3").trigger("reset");
                    }
                });
            }
        }else{
            alert("Please fill all fields");
        }

        });

      });



      $('#form4').on('submit', function (e) {

        e.preventDefault();
        var address = $("#address").val();
        if (address != "") {
          $.ajax({
            type: 'post',
            url: 'otherinformation.php',
            data: $('form').serialize(),
            success: function (data) {
                alert('Address Submit successfully');
                $(".displaytabledata").html(data);
                $("#form4").trigger("reset");
            }
        });
        }else{
            alert("Please fill all fields");
        }
    });



      $.ajax({
                type: 'POST',
                url: 'edit_profile_validation.php',
                data:{id:id, job_ID:job_ID},
                success: function (data) {
                  $(".datadisplay").html(data);
                }
            });


      $.ajax({
                type: 'POST',
                url: 'education.php',
                data:{id:id, job_ID:job_ID},
                success: function (data) {
                  $(".datadisplay1").html(data);
                }
            });


      $.ajax({
                type: 'POST',
                url: 'otherinformation.php',
                data:{id:id, job_ID:job_ID},
                success: function (data) {
                  $(".displaytabledata").html(data);
                }
            });

    </script>
    
    <script type="text/javascript">
    $(".abc option[value='<?php if (isset($editprofile->fetchdata[1])) { echo $editprofile->fetchdata[1]; }; ?>']").attr("selected","selected");
    $(".years option[value='<?php if (isset($editprofile->fetchdata[2])) { echo $editprofile->fetchdata[2]; } ?>']").attr("selected","selected");
    $(".month option[value='<?php if (isset($editprofile->fetchdata[3])) { echo $editprofile->fetchdata[3]; } ?>']").attr("selected","selected");
    $(".location option[value='<?php if (isset($editprofile->fetchdata[4])) { echo $editprofile->fetchdata[4]; } ?>']").attr("selected","selected");
</script>
</body>
</html>
<script type="text/javascript">
    $(".classdata option[value='<?php if (isset($educationdata->edudata[1])) { echo $educationdata->edudata[1]; } ?>']").attr("selected","selected");
    $(".Passingyears option[value='<?php if (isset($educationdata->edudata[2])) { echo $educationdata->edudata[2]; } ?>']").attr("selected","selected");
    $(".joblocationdata option[value='<?php if (isset($educationdata->edudata[3])) { echo $educationdata->edudata[3]; } ?>']").attr("selected","selected");
</script>