<?php

require_once('database.php');  


class daleterecord extends database
{
	
	public function deletedatafunction(){
		if (isset($_GET['did']) && isset($_GET['duserid']) && $_GET['deid']) {
			$did = $_GET['did'];
    	$duserid = $_GET['duserid'];
    	$deid = $_GET['deid'];		
		mysqli_query($this->connect(), "DELETE FROM experience WHERE experience_id='$did' && ID='$duserid' && job_ID='$deid'");
		header("location:profile_edit.php#form2");
		}
		
	}


	public function deletefunction(){

		if (isset($_GET['edid']) && isset($_GET['eduserid']) && $_GET['edeid']) {
			$did = $_GET['edid'];
	    	$duserid = $_GET['eduserid'];
	    	$deid = $_GET['edeid'];		
			mysqli_query($this->connect(), "DELETE FROM education WHERE Education_id='$did' && ID='$duserid' && job_ID='$deid'");
			header("location:profile_edit.php#form3");
		}
		
	}
}

$datadelete = new daleterecord();
$datadelete->deletedatafunction();
$datadelete->deletefunction();
?>